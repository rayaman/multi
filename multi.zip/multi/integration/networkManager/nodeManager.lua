--[[
MIT License

Copyright (c) 2022 Ryan Ward

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
]]
local multi, thread = require("multi"):init()
local cmd = require("multi.integration.networkManager.cmds")
local net = require("net")
local bin = require("bin")
local nodes = { -- Testing stuff
    
}
function multi:newNodeManager(port)
    print("Running node manager on port: "..(port or cmd.defaultManagerPort))
    local server = net:newTCPServer(port or cmd.defaultManagerPort)
    server.OnDataRecieved(function(serv, data, client)
        local cmd = data:match("!(.+)!")
        data = data:gsub("!"..cmd.."!","")
        if cmd == "NODES" then 
            for i,v in ipairs(nodes) do
                -- Sample data
                serv:send(client, "!NODE!".. v[1].."|"..v[2].."|"..v[3])
            end
        elseif cmd == "REG_NODE" then
            local name, ip, port = data:match("(.-)|(.-)|(.+)")
            table.insert(nodes,{name,ip,port})
            print("Registering Node:",name, ip, port)
        end
    end)
end